﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Nadra.Api.Core.Models;
using Nadra.Api.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Nadra.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UpdateRequestsController : ControllerBase
    {
        private readonly NadraDbContext _context;

        public UpdateRequestsController(NadraDbContext context)
        {
            _context = context;
        }

        // ---------------- DepartmentOfficer: Submit Request ----------------
        [HttpPost]
        [Authorize(Roles = "DepartmentOfficer")]
        public async Task<IActionResult> SubmitRequest([FromBody] CitizenUpdateRequest request)
        {
            request.Status = "Pending";
            request.RequestedDate = DateTime.Now;
            _context.CitizenUpdateRequests.Add(request);
            await _context.SaveChangesAsync();
            return Ok(request);
        }

        // ---------------- Admin: View All Requests ----------------
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAll()
        {
            var requests = await _context.CitizenUpdateRequests
                .Include(r => r.Citizen)
                .ToListAsync();
            return Ok(requests);
        }

        // ---------------- Admin: Approve/Reject ----------------
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] string status)
        {
            var request = await _context.CitizenUpdateRequests.FindAsync(id);
            if (request == null) return NotFound();

            request.Status = status;

            if (status == "Approved")
            {
                var citizen = await _context.Citizens.FindAsync(request.CitizenId);
                if (citizen != null)
                {
                    switch (request.RequestedField.ToLower())
                    {
                        case "fullname": citizen.FullName = request.NewValue; break;
                        case "address": citizen.Address = request.NewValue; break;
                        case "fathername": citizen.FatherName = request.NewValue; break;
                        case "maritalstatus": citizen.MaritalStatus = request.NewValue; break;
                        case "gender": citizen.Gender = request.NewValue; break;
                            // CNIC & DOB cannot be updated
                    }
                }
            }

            await _context.SaveChangesAsync();
            return Ok(request);
        }
    }
}
