﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nadra.Api.Data;
using Nadra.Api.DTOs;
using Nadra.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Nadra.Api.Controllers
{
    [Authorize(Roles = "Admin")]
    [ApiController]
    [Route("api/admin/citizens")]
    public class AdminCitizenController : ControllerBase
    {
        private readonly NadraDbContext _context;

        public AdminCitizenController(NadraDbContext context)
        {
            _context = context;
        }

        // GET: api/admin/citizens
        [HttpGet]
        public async Task<IActionResult> GetAllCitizens()
        {
            var citizens = await _context.Citizens
                .Select(c => new CitizenResponseDto
                {
                    FullName = c.FullName,
                    CNIC = c.CNIC,
                    Address = c.Address,
                    MaritalStatus = c.MaritalStatus,
                    Gender = c.Gender,
                    DateOfBirth = c.DateOfBirth
                }).ToListAsync();

            return Ok(citizens);
        }

        // GET: api/admin/citizens/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCitizenById(int id)
        {
            var c = await _context.Citizens.FindAsync(id);
            if (c == null) return NotFound();

            return Ok(new CitizenResponseDto
            {
                FullName = c.FullName,
                CNIC = c.CNIC,
                Address = c.Address,
                MaritalStatus = c.MaritalStatus,
                Gender = c.Gender,
                DateOfBirth = c.DateOfBirth
            });
        }

        // POST: api/admin/citizens
        [HttpPost]
        public async Task<IActionResult> CreateCitizen([FromBody] CitizenCreateDto dto)
        {
            // CNIC uniqueness check
            if (await _context.Citizens.AnyAsync(c => c.CNIC == dto.CNIC))
                return BadRequest("CNIC already exists");

            var citizen = new Citizen
            {
                FullName = dto.FullName,
                CNIC = dto.CNIC,
                FatherName = dto.FatherName,
                DateOfBirth = dto.DateOfBirth,
                Gender = dto.Gender,
                Address = dto.Address,
                MaritalStatus = dto.MaritalStatus
            };

            _context.Citizens.Add(citizen);
            await _context.SaveChangesAsync();

            return Ok("Citizen created successfully");
        }

        // PUT: api/admin/citizens/{id}  → update non-sensitive fields
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCitizen(int id, [FromBody] CitizenUpdateDto dto)
        {
            var c = await _context.Citizens.FindAsync(id);
            if (c == null) return NotFound();

            c.Address = dto.Address;
            c.MaritalStatus = dto.MaritalStatus;

            await _context.SaveChangesAsync();
            return Ok("Citizen updated successfully");
        }

        // GET: api/admin/update-requests
        [HttpGet("/api/admin/update-requests")]
        public async Task<IActionResult> GetAllUpdateRequests()
        {
            var requests = await _context.CitizenUpdateRequests
                .Include(r => r.Citizen)
                .Include(r => r.Department)
                .ToListAsync();

            return Ok(requests);
        }

        // PUT: api/admin/update-requests/{id}/approve
        [HttpPut("/api/admin/update-requests/{id}/approve")]
        public async Task<IActionResult> ApproveUpdateRequest(int id)
        {
            var request = await _context.CitizenUpdateRequests
                .Include(r => r.Citizen)
                .FirstOrDefaultAsync(r => r.RequestId == id);

            if (request == null) return NotFound();

            // Apply the update
            if (request.RequestedField == "Address") request.Citizen.Address = request.NewValue;
            if (request.RequestedField == "MaritalStatus") request.Citizen.MaritalStatus = request.NewValue;

            request.Status = "Approved";
            await _context.SaveChangesAsync();

            return Ok("Request approved and applied");
        }

        // PUT: api/admin/update-requests/{id}/reject
        [HttpPut("/api/admin/update-requests/{id}/reject")]
        public async Task<IActionResult> RejectUpdateRequest(int id)
        {
            var request = await _context.CitizenUpdateRequests.FindAsync(id);
            if (request == null) return NotFound();

            request.Status = "Rejected";
            await _context.SaveChangesAsync();

            return Ok("Request rejected");
        }
    }
}
