﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Nadra.Api.Core.Models;
using Nadra.Api.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Nadra.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CitizensController : ControllerBase
    {
        private readonly NadraDbContext _context;

        public CitizensController(NadraDbContext context)
        {
            _context = context;
        }

        // ---------------- Admin: Get All Citizens ----------------
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAll()
        {
            var citizens = await _context.Citizens.ToListAsync();
            return Ok(citizens);
        }

        // ---------------- DepartmentOfficer: Verify by CNIC ----------------
        [HttpGet("{cnic}")]
        [Authorize(Roles = "DepartmentOfficer,Admin")]
        public async Task<IActionResult> Verify(string cnic)
        {
            var citizen = await _context.Citizens.FirstOrDefaultAsync(c => c.CNIC == cnic);
            if (citizen == null) return NotFound("Citizen not found");
            return Ok(citizen);
        }

        // ---------------- Admin: Create Citizen ----------------
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([FromBody] Citizen citizen)
        {
            if (await _context.Citizens.AnyAsync(c => c.CNIC == citizen.CNIC))
                return BadRequest("CNIC already exists");

            _context.Citizens.Add(citizen);
            await _context.SaveChangesAsync();
            return Ok(citizen);
        }

        // ---------------- Admin: Update Citizen ----------------
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] Citizen citizen)
        {
            var existing = await _context.Citizens.FindAsync(id);
            if (existing == null) return NotFound();

            existing.FullName = citizen.FullName;
            existing.Address = citizen.Address;
            existing.FatherName = citizen.FatherName;
            existing.Gender = citizen.Gender;
            existing.MaritalStatus = citizen.MaritalStatus;
            // CNIC is immutable
            await _context.SaveChangesAsync();
            return Ok(existing);
        }

        // ---------------- Admin: Delete/Deactivate Citizen ----------------
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var citizen = await _context.Citizens.FindAsync(id);
            if (citizen == null) return NotFound();
            citizen.IsAlive = false;
            await _context.SaveChangesAsync();
            return Ok("Citizen deactivated");
        }
    }
}
