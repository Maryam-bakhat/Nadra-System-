﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nadra.Api.Data;
using Nadra.Api.DTOs;
using Nadra.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Nadra.Api.Controllers
{
    [Authorize(Roles = "DepartmentOfficer")]
    [ApiController]
    [Route("api/department")]
    public class DepartmentController : ControllerBase
    {
        private readonly NadraDbContext _context;

        public DepartmentController(NadraDbContext context)
        {
            _context = context;
        }

        // GET: api/department/verify/{cnic}
        [HttpGet("verify/{cnic}")]
        public async Task<IActionResult> VerifyCitizen(string cnic)
        {
            var citizen = await _context.Citizens
                .Where(c => c.CNIC == cnic)
                .Select(c => new CitizenResponseDto
                {
                    FullName = c.FullName,
                    CNIC = c.CNIC,
                    Address = c.Address,
                    MaritalStatus = c.MaritalStatus,
                    Gender = c.Gender,
                    DateOfBirth = c.DateOfBirth
                }).FirstOrDefaultAsync();

            if (citizen == null) return NotFound("Citizen not found");
            return Ok(citizen);
        }

        // POST: api/department/update-request
        [HttpPost("update-request")]
        public async Task<IActionResult> SubmitUpdateRequest([FromBody] CitizenUpdateRequestDto dto)
        {
            // Check if citizen exists
            var citizen = await _context.Citizens.FindAsync(dto.CitizenId);
            if (citizen == null) return NotFound("Citizen not found");

            var userId = User.Claims.FirstOrDefault(c => c.Type == System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var user = await _context.Users.FindAsync(userId);

            var request = new CitizenUpdateRequest
            {
                CitizenId = dto.CitizenId,
                RequestedByDepartmentId = user.DepartmentId ?? 0,
                RequestedField = dto.RequestedField,
                OldValue = dto.OldValue,
                NewValue = dto.NewValue,
                Status = "Pending"
            };

            _context.CitizenUpdateRequests.Add(request);
            await _context.SaveChangesAsync();

            return Ok("Update request submitted");
        }
    }
}
