﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Nadra.Api.Models
{
    public class CitizenUpdateRequest
    {
        [Key]
        public int RequestId { get; set; }

        [Required]
        [ForeignKey("Citizen")]
        public int CitizenId { get; set; }
        public Citizen Citizen { get; set; }

        [Required]
        [ForeignKey("Department")]
        public int RequestedByDepartmentId { get; set; }
        public Department Department { get; set; }

        [Required]
        [MaxLength(50)]
        public string RequestedField { get; set; }

        [MaxLength(200)]
        public string OldValue { get; set; }

        [MaxLength(200)]
        public string NewValue { get; set; }

        [Required]
        [MaxLength(20)]
        public string Status { get; set; } = "Pending"; // Pending / Approved / Rejected

        public DateTime RequestedDate { get; set; } = DateTime.Now;
    }
}
