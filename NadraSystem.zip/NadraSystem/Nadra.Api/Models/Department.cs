﻿using System.ComponentModel.DataAnnotations;

namespace Nadra.Api.Models
{
    public class Department
    {
        [Key]
        public int DepartmentId { get; set; }

        [Required]
        [MaxLength(100)]
        public string DepartmentName { get; set; } // Union Council / Bank / Police

        [Required]
        [MaxLength(50)]
        public string DepartmentType { get; set; } // Government / Financial / Law Enforcement

        public bool IsActive { get; set; } = true;
    }
}
