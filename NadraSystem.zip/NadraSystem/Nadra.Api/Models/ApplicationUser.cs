﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace Nadra.Api.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string Role { get; set; } // Admin / DepartmentOfficer

        [ForeignKey("Department")]
        public int? DepartmentId { get; set; } // Nullable for Admin
        public Department Department { get; set; }
    }
}
