﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Nadra.Api.Models
{
    public class Citizen
    {
        [Key]
        public int CitizenId { get; set; }

        [Required]
        [MaxLength(100)]
        public string FullName { get; set; }

        [Required]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "CNIC must be 13 digits")]
        public string CNIC { get; set; } // Immutable

        [Required]
        [MaxLength(100)]
        public string FatherName { get; set; }

        [Required]
        public DateTime DateOfBirth { get; set; }

        [Required]
        [MaxLength(10)]
        public string Gender { get; set; } // Male / Female / Other

        [Required]
        [MaxLength(200)]
        public string Address { get; set; }

        [Required]
        [MaxLength(20)]
        public string MaritalStatus { get; set; } // Single / Married

        [Required]
        [MaxLength(20)]
        public string Nationality { get; set; } = "Pakistani";

        public bool IsAlive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
