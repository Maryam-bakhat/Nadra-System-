﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Nadra.Api.Core.Models;

namespace Nadra.Api.Infrastructure.Data
{
    public class NadraDbContext : IdentityDbContext<ApplicationUser>
    {
        public NadraDbContext(DbContextOptions<NadraDbContext> options)
            : base(options) { }

        public DbSet<Citizen> Citizens { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<CitizenUpdateRequest> CitizenUpdateRequests { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Citizen>().HasIndex(c => c.CNIC).IsUnique();
        }
    }
}

