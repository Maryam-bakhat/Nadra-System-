﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Nadra.Api.Models;

namespace Nadra.Api.Data
{
    public class NadraDbContext : IdentityDbContext<ApplicationUser>
    {
        public NadraDbContext(DbContextOptions<NadraDbContext> options)
            : base(options)
        {
        }

        public DbSet<Citizen> Citizens { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<CitizenUpdateRequest> CitizenUpdateRequests { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Citizen>()
                .HasIndex(c => c.CNIC)
                .IsUnique();

            
            builder.Entity<CitizenUpdateRequest>()
                .HasOne(r => r.Citizen)
                .WithMany()
                .HasForeignKey(r => r.CitizenId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<CitizenUpdateRequest>()
                .HasOne(r => r.Department)
                .WithMany()
                .HasForeignKey(r => r.RequestedByDepartmentId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<ApplicationUser>()
                .HasOne(u => u.Department)
                .WithMany()
                .HasForeignKey(u => u.DepartmentId)
                .OnDelete(DeleteBehavior.SetNull);
        }
    }
}
