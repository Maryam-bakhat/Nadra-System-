﻿using static Nadra.Api.Core.Models.CitizenUpdateRequestModel;

namespace Nadra.Api.Core.Models
{
    public class Citizen
    {
        public int CitizenId { get; set; }
        public string FullName { get; set; }
        public string CNIC { get; set; }
        public string FatherName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string MaritalStatus { get; set; }
        public string Nationality { get; set; } = "Pakistani";
        public bool IsAlive { get; set; } = true;
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public ICollection<CitizenUpdateRequest> UpdateRequests { get; set; }
    }
}
