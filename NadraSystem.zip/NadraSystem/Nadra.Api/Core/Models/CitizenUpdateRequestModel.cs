﻿namespace Nadra.Api.Core.Models
{
    public class CitizenUpdateRequest
    {
        public int RequestId { get; set; }
        public int CitizenId { get; set; }
        public int RequestedByDepartmentId { get; set; }
        public string RequestedField { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public string Status { get; set; } = "Pending";
        public DateTime RequestedDate { get; set; } = DateTime.Now;

        public Citizen Citizen { get; set; }
    }
}
