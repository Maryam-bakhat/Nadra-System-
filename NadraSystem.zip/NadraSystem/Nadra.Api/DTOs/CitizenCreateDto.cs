﻿namespace Nadra.Api.DTOs
{
    public class CitizenCreateDto
    {
        public string FullName { get; set; }
        public string CNIC { get; set; }
        public string FatherName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string MaritalStatus { get; set; }
    }
}
