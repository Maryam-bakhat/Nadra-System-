﻿namespace Nadra.Api.DTOs
{
    public class CitizenUpdateRequestDto
    {
        public int CitizenId { get; set; }
        public string RequestedField { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
    }
}
