﻿namespace Nadra.Api.DTOs
{
    public class CitizenUpdateDto
    {
        public string Address { get; set; }
        public string MaritalStatus { get; set; }
    }
}
